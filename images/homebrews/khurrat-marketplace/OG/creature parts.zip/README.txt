Hi!! Thank for download
You can download Fonts via the following link

https://www.fontfabric.com/fonts/nexa/

https://www.ffonts.net/NexaBold.font


Contact me if you have any questions
yogo.donald@gmail.com

Please Enjoy!