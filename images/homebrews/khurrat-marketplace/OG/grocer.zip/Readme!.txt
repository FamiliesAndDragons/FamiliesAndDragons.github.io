Hello,

Thank for purchasing and using this logo.
You can open on adobe illustrator for change name logo, before you change name logo you must download and install this font:

https://elements.envato.com/brinson-rought-vintage-serif-font-PVJXYT8


Thanks,
Blankids