Wolf Vintage Logo

Fonts can be easily downloaded from the link below:
https://fonts.google.com/specimen/Playfair+Display

Thanks! and enjoy the volume and dont't forget to rate this volume.