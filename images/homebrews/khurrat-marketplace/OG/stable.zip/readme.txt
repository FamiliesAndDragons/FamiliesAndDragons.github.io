thank you for buying my logo, before you use, 
please download and install the following font if you want a change 

"https://fonts.adobe.com/fonts/futura-pt"