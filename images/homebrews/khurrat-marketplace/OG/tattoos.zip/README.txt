Hi!! Thank for download
You can download Fonts via the following link

https://www.dafont.com/no-continue.font

Contact me if you have any questions
yogo.donald@gmail.com

Please Enjoy!