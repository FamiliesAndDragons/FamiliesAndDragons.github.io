


var data = [
    [1, "jack",55],
    [2, "anna", 11]
];

    document.addEventListener("DOMContentLoaded",function(){

    var tbody = document.getElementById("table-body");

    var row = document.createElement("tr");
    var col1 = document.createElement("td");
    col1.textContent - "apple"
    row.appendChild(col1);
    tbody.appendChild(row);



    });





